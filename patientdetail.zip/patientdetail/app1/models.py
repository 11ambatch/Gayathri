from django.db import models

# Create your models here.
class Patient(models.Model):
	pname=models.CharField(max_length=30)
	pid=models.IntegerField()
	city=models.CharField(max_length=30)
	treatment=models.CharField(max_length=30)
	doctor=models.CharField(max_length=30)
	bill=models.IntegerField()
