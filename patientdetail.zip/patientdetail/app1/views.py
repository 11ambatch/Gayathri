from django.shortcuts import render
from .serializers import*
from .models import Patient
from rest_framework import status
from rest_framework.response import Response
from rest_framework import viewsets
from rest_framework.authentication import SessionAuthentication
from rest_framework.permissions import IsAdminUser
import requests

# Create your views here.
class Heathcare(viewsets.ModelViewSet):
		queryset=Patient.objects.all()
		serializer_class=HealthCare
		authentication_classes=[SessionAuthentication]
		permission_classes=[IsAdminUser]

def patient(request):
	res=requests.get('http://127.0.0.1:8000/p/')
	data=res.json()
	return render(request,'app1/patient.html',{'s':data})

 