from rest_framework import serializers
from app1.models import Patient

class HealthCare(serializers.ModelSerializer):
	class Meta:
		model=Patient
		fields="__all__"